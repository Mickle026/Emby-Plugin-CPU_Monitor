﻿using MediaBrowser.Model.Plugins;

namespace CPUMonitor
{
    public class PluginConfiguration : BasePluginConfiguration
    {

	}
}
